# MATCOM COMETS MODEL SCHOOL CBT
Android Studio project for an offline-capable CBT portal.

Features:
- School-branded CBT portal
- Student name, class, subject and exam duration
- Multiple-choice examination engine
- Timer and automatic submission
- JSON question-bank upload
- Large question banks loaded locally through browser file APIs
- Offline use after installation
- JSON template download

Build:
1. Open this folder in Android Studio.
2. Allow Gradle to sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be under app/build/outputs/apk/debug/.

Question format:
[
  {
    "question": "Question text",
    "options": ["A","B","C","D"],
    "answer": 1
  }
]
The answer is the zero-based option number.


## Admin Dashboard
The CBT now includes an Admin Dashboard that can import multiple question files in one operation:
- JSON (`questions` array or a raw array)
- CSV
- Excel `.xlsx`
- Multiple files can be selected at once.
- Questions are normalized into a common format and stored in localStorage.
- Class, subject and topic metadata are supported.
- The dashboard shows question totals by class and subject.
- The full bank can be exported as JSON.
- CSV and JSON templates are built in.

Recommended CSV columns:
`question,A,B,C,D,answer,class,subject,topic,marks`

For very large banks, keep files reasonably sized for the Android device/browser memory. The app combines selected files before storing them locally.


## School Logo
The uploaded MATCOM COMETS MODEL SCHOOL logo is included in `app/src/main/assets/matcom_logo.png` and displayed in the CBT portal header.


## Class → Subject → Topic Organization
The Admin Dashboard now maintains a three-level hierarchy:
1. **Class** — e.g. Primary 4
2. **Subject** — e.g. Mathematics
3. **Topic** — e.g. Fractions

The dashboard provides:
- Cascading Class → Subject → Topic selectors.
- A visual expandable question-bank tree.
- Question counts at each level.
- A preview table for the selected group.
- CBT filtering: when a Class/Subject/Topic is selected in the dashboard, starting the CBT uses only that question group.
- Imported questions are normalized with `class`, `subject`, and `topic` fields.


## Exam Duration & Number of Questions
The Admin Dashboard now supports exam configuration for each Class → Subject → Topic:
- Set exam duration in minutes.
- Set the number of questions.
- Save settings for the selected hierarchy.
- Restore saved settings later.
- The student exam randomly selects the requested number of questions from the selected group without repetition.
- The CBT prevents starting when the requested number exceeds the available questions.


## Results Management
Each submitted examination is saved locally with student name, class, subject, topic, score, percentage, duration, time used and date/time. Admin can filter results, search students, export CSV and print results.


## Build APK Without Android Studio
See `BUILD_APK_WITHOUT_ANDROID_STUDIO.md`. The included GitHub Actions workflow builds `app-debug.apk` in the cloud and exposes it as a downloadable artifact.
