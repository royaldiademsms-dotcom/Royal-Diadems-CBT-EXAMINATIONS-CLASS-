# Build the MATCOM COMETS CBT APK without Android Studio

This project is configured to build automatically with GitHub Actions.

## Phone-only method

1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository, for example `matcom-comets-cbt`.
3. Upload/extract all files from this project into the repository. Make sure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab.
5. Select **Build MATCOM COMETS CBT APK**.
6. Tap **Run workflow**.
7. Wait for the build to finish.
8. Open the completed workflow run.
9. Under **Artifacts**, download `Matcom-Comets-CBT-debug-APK`.
10. Extract the downloaded artifact and install `app-debug.apk` on the Android phone.

## Important
- Android Studio is NOT required on the phone.
- The APK is compiled by GitHub's cloud runner.
- The generated APK is a debug APK suitable for testing/internal school use.
- Android may ask you to allow installation from the browser/file manager. Only enable that permission for a source you trust.
- For public distribution through Google Play, a signed release build should be generated instead.
